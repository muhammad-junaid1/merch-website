<!DOCTYPE html>
<html>
<head>
    <title>Mail</title>
</head>
<body>
    <p>Name: {{ $username }}</p>
    <p>Phone No: {{ $phone }}</p>
    <p>Company Email: {{ $companyEmail }}</p>
    <p>Company: {{ $company }}</p>
    <p>Message:</p>
    <p>{{$messages}}</p>

</body>
</html>