<!DOCTYPE html>
<html>
<head>
    <title>Mail</title>
</head>
<body>
    <p>Name: <?php echo e($username); ?></p>
    <p>Phone No: <?php echo e($phone); ?></p>
    <p>Company Email: <?php echo e($companyEmail); ?></p>
    <p>Company: <?php echo e($company); ?></p>
    <p>Message:</p>
    <p><?php echo e($messages); ?></p>

</body>
</html><?php /**PATH D:\your-merch\resources\views/Mail.blade.php ENDPATH**/ ?>